#ifndef TWO_H
    #define TWO_H
    
    #include <stdio.h>

    void myfunc();
#endif
