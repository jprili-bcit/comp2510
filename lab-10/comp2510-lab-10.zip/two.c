#include "two.h"

void myfunc() {
    printf("hello\n");
}
