#include "one.h"
#include "two.h"

int main(void) {
    printf("%lf\n", PI);
    myfunc();
    return 0;
}
